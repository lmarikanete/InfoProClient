#!/bin/bash

# Aktualizace OS

echo ""
echo "Instaluji aktualizace OS ..."
echo ""
sleep 3
apt update && apt upgrade -y

# Instalace klienta vč. závislostí a úprav OS

echo ""
echo "Instaluji InfoPro klienta ..."
echo ""
sleep 2
mkdir /home/infopro/infopro
rm -rf /home/infopro/infopro/*
dpkg -i infoproclient.deb
apt --fix-broken install -y
rm -rf /usr/share/backgrounds/*
cp lightdm.conf /etc/lightdm
cp grub /etc/default
rm -f /etc/initramfs-tools/conf.d/resume
rm -f /boot/grub/infopro_boot.png
cp 10_linux /etc/grub.d
cp splashie.service /etc/systemd/system

# Instalace VNC a SSH

echo ""
echo "Instaluji VNC a SSH"
echo ""
sleep 3
cp x11vnc.service /etc/systemd/system/
systemctl daemon-reload
systemctl enable x11vnc ssh splashie
systemctl stop x11vnc
cp x11vnc /etc

# Nastavení XFCE4 a firewallu

echo ""
echo "Nastavuji prostředí a firewall ..."
echo ""
sleep 3
firewall-cmd --permanent --zone=trusted --add-service=vnc-server
firewall-cmd --permanent --zone=trusted --add-service=ssh
firewall-cmd --permanent --zone=public --add-service=vnc-server
firewall-cmd --permanent --zone=public --add-service=ssh
firewall-cmd --reload
rm -rf /home/infopro/.config/xfce4/*
cp -r xfce4 /home/infopro/.config
chown -R infopro:infopro /home/infopro/.config/xfce4
echo "Vitejte v konzoli InfoPro klienta!" > /etc/motd
cp interfaces /etc/network/

# Vyčištění - apt autoremove

echo ""
echo "Čistím instalaci ..."
echo ""
sleep 3
apt autoremove desktop-base gnome-keyring -y
apt clean

# Splash a quiet


echo ""
echo "Nastavuji splash a tichý boot"
echo ""
sleep 3
apt install plymouth-themes -y
cp debian-logo.png /usr/share/plymouth
cp spinfinity.plymouth /usr/share/plymouth/themes/spinfinity
plymouth-set-default-theme -R spinfinity

# Reboot

echo ""
echo "Nainstalováno OK, restartuji ..."
echo ""
sleep 3
systemctl reboot
exit