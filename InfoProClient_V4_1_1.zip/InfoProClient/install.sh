##!/bin/bash
echo "Instaluji aktualizace OS ..."
sleep 3
apt update && apt upgrade -y
echo "Instaluji InfoPro klienta ..."
sleep 2
mkdir /home/infopro/infopro
rm -rf /home/infopro/infopro/*
dpkg -i infoproclient.deb
apt --fix-broken install -y
rm -rf /usr/share/backgrounds/*
cp lightdm.conf /etc/lightdm
cp grub /etc/default
apt install chromium-l10n -y
rm -f /etc/initramfs-tools/conf.d/resume
rm -f /boot/grub/infopro_boot.png
cp 10_linux /etc/grub.d
cp splashie.service /etc/systemd/system
update-grub
echo "Instaluji VNC a SSH"
sleep 3
cp x11vnc.service /etc/systemd/system/
systemctl daemon-reload
systemctl enable x11vnc ssh splashie
systemctl stop x11vnc
cp x11vnc /etc
echo "Nastavuji prostředí a firewall ..."
sleep 3
firewall-cmd --permanent --zone=trusted --add-service=vnc-server
firewall-cmd --permanent --zone=trusted --add-service=ssh
firewall-cmd --permanent --zone=public --add-service=vnc-server
firewall-cmd --permanent --zone=public --add-service=ssh
firewall-cmd --reload
rm -rf /home/infopro/.config/xfce4/*
cp -r xfce4 /home/infopro/.config
chown -R infopro:infopro /home/infopro/.config/xfce4
echo "Vitejte v konzoli InfoPro klienta!" > /etc/motd
echo "Čistím instalaci ..."
sleep 3
apt remove desktop-base gnome-keyring -y
apt clean
echo "Nastavuji splash a tichý boot"
sleep 3
apt install plymouth-themes -y
cp debian-logo.png /usr/share/plymouth
cp spinfinity.plymouth /usr/share/plymouth/themes/spinfinity
plymouth-set-default-theme -R spinfinity
echo "Nainstalováno OK, restartuji ..."
sleep 3
systemctl reboot
exit